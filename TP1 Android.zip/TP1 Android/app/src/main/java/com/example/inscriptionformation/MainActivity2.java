package com.example.inscriptionformation;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private TextView info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        info = findViewById(R.id.info);

        String nom = getIntent().getStringExtra("NOM");
        String email = getIntent().getStringExtra("EMAIL");
        String phone = getIntent().getStringExtra("PHONE");
        String adresse = getIntent().getStringExtra("ADRESSE");
        String ville = getIntent().getStringExtra("VILLE");

        String recap = "Nom & Prénom: " + nom + "\n"
                + "Email: " + email + "\n"
                + "Téléphone: " + phone + "\n"
                + "Adresse: " + adresse + "\n"
                + "Ville: " + ville;

        info.setText(recap);
    }
}
